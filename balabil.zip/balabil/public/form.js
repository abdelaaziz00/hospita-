// Refined form validation and handling script for aesthetic consultation

// Global variables 
let currentStep = 0;
const steps = document.querySelectorAll('.step');
const progressSteps = document.querySelectorAll('.progress-step');

// Initialize the form
document.addEventListener('DOMContentLoaded', function() {
    // Update progress bar on load
    updateProgress();
    
    // Set up checkbox behavior for step 1 (allow only one selection)
    const needsCheckboxes = document.querySelectorAll('input[name="needs[]"]');
    needsCheckboxes.forEach(checkbox => {
        checkbox.addEventListener('change', function() {
            if (this.checked) {
                needsCheckboxes.forEach(cb => {
                    if (cb !== this) cb.checked = false;
                });
                
                // Add visual feedback for selected item
                needsCheckboxes.forEach(cb => {
                    const parent = cb.closest('.check-items');
                    if (parent) {
                        parent.classList.toggle('selected', cb.checked);
                    }
                });
            }
        });
    });
    
    // Update the hidden country input when the user selects a country
    const countrySelect = document.getElementById('country');
    if (countrySelect) {
        countrySelect.addEventListener('change', function() {
            document.getElementById('hiddenCountry').value = this.value;
            updateCityOptions(this.value);
        });
    }
    
    // Add event listeners for radio buttons to enhance visual feedback
    const radioButtons = document.querySelectorAll('input[type="radio"]');
    radioButtons.forEach(radio => {
        radio.addEventListener('change', function() {
            const radioGroup = document.querySelectorAll(`input[name="${this.name}"]`);
            radioGroup.forEach(btn => {
                const parent = btn.closest('.radio-item');
                if (parent) {
                    parent.classList.toggle('selected', btn.checked);
                }
            });
        });
    });
    
    // Form submission handler
    const consultationForm = document.getElementById('consultationForm');
    if (consultationForm) {
        consultationForm.addEventListener('submit', handleFormSubmit);
    }
    
    // Add animation to buttons
    const buttons = document.querySelectorAll('.button');
    buttons.forEach(button => {
        button.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-3px)';
        });
        
        button.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });
    
    // Focus first input in active step
    focusFirstInput();
});

// Update progress indicator
function updateProgress() {
    progressSteps.forEach((step, idx) => {
        if (idx < currentStep) {
            step.classList.add('complete');
            step.classList.remove('active');
        } else if (idx === currentStep) {
            step.classList.add('active');
            step.classList.remove('complete');
        } else {
            step.classList.remove('active', 'complete');
        }
    });
}

// Update city dropdown based on selected country
function updateCityOptions(country) {
    const citySelection = document.getElementById('city-selection');
    const citySelect = document.getElementById('city');
    
    if (!citySelection || !citySelect) return;
    
    citySelect.innerHTML = ''; // Clear previous options
    
    if (country === 'Morocco') {
        const cities = ['Marrakech', 'Casablanca', 'Rabat', 'Autre'];
        addOptionsToSelect(citySelect, cities);
        citySelection.style.display = 'block';
    } else if (country === 'Europe') {
        const cities = ['France', 'Belgique', 'Italie', 'Autre'];
        addOptionsToSelect(citySelect, cities);
        citySelection.style.display = 'block';
    } else {
        citySelection.style.display = 'none';
    }
    
    // Skip to next step for "Other" country
    if (country === 'Other') {
        changeStep(1);
    }
}

// Helper to add options to select element
function addOptionsToSelect(selectElement, options) {
    options.forEach(option => {
        const optElement = document.createElement('option');
        optElement.value = option;
        optElement.textContent = option;
        selectElement.appendChild(optElement);
    });
}

// Global variable to track timing path
let pr = 0;

// Move to next/previous step
function changeStep(direction) {
    // Get current form fields
    const currentForm = steps[currentStep].querySelectorAll('input, select, textarea');
    
    // Validation for step 1 (needs)
    if (currentStep === 0 && direction === 1) {
        const checkedBoxes = Array.from(steps[0].querySelectorAll('input[type="checkbox"]')).filter(box => box.checked);
        if (checkedBoxes.length === 0) {
            showNotification("Veuillez sélectionner au moins un besoin pour continuer", "warning");
            highlightSection(steps[0].querySelector('.labels'));
            return;
        }
    }
    
    // Validate required fields
    let isValid = true;
    for (const field of currentForm) {
        if (field.required && !field.value && direction === 1) {
            isValid = false;
            field.classList.add('invalid');
            field.reportValidity();
            break;
        } else {
            field.classList.remove('invalid');
        }
    }
    
    if (!isValid && direction === 1) return;
    
    // Special handling for timing
    if (currentStep === 3 && direction === 1) {
        const timing = document.querySelector('input[name="timing"]:checked');
        if (timing && (timing.value === "Plus de 2 mois" || timing.value === "Dans l'année")) {
            currentStep += 2; // Skip Étape 5 (appointment)
            pr = 1;
        } else {
            currentStep += 1; // Proceed normally
            pr = 0;
        }
    } else {
        currentStep += direction;
    }
    
    // Ensure step is valid
    if (currentStep < 0) currentStep = 0;
    if (currentStep >= steps.length) currentStep = steps.length - 1;
    
    // Update UI
    steps.forEach((step, index) => {
        step.classList.toggle('active', index === currentStep);
    });
    
    // Update progress bar
    updateProgress();
    
    // Update buttons
    document.getElementById('prevBtn').disabled = currentStep === 0;
    document.getElementById('nextBtn').style.display = currentStep === steps.length - 1 ? 'none' : 'inline-block';
    document.getElementById('submitBtn').style.display = currentStep === steps.length - 1 ? 'inline-block' : 'none';
    
    // Scroll to top of form and focus first input
    document.querySelector('.form-container').scrollTop = 0;
    focusFirstInput();
    
    // Add animation to active step
    if (steps[currentStep]) {
        steps[currentStep].style.animation = 'none';
        setTimeout(() => {
            steps[currentStep].style.animation = 'fadeIn 0.4s ease-in';
        }, 10);
    }
}

// Function to go back to the previous step
function PréchangeStep() {
    // Check if we're at Étape 6 (index 5) and pr is 1
    if (currentStep === 5 && pr === 1) {
        changeStep(-2); // Go back two steps if at Étape 6 and pr is 1
    } else {
        changeStep(-1); // Go back one step in all other cases
    }
}

// Focus first input in active step
function focusFirstInput() {
    setTimeout(() => {
        const activeStep = document.querySelector('.step.active');
        if (activeStep) {
            const firstInput = activeStep.querySelector('input, select, textarea');
            if (firstInput) firstInput.focus();
        }
    }, 400); // Wait for animation to complete
}

// Show notification
function showNotification(message, type = 'info') {
    // Create notification element if it doesn't exist
    let notification = document.querySelector('.notification');
    if (!notification) {
        notification = document.createElement('div');
        notification.className = 'notification';
        document.body.appendChild(notification);
    }
    
    // Set notification content and type
    notification.textContent = message;
    notification.className = `notification ${type}`;
    
    // Show notification
    notification.style.display = 'block';
    notification.style.animation = 'fadeIn 0.3s ease-in';
    
    // Hide notification after 3 seconds
    setTimeout(() => {
        notification.style.animation = 'fadeOut 0.3s ease-out';
        setTimeout(() => {
            notification.style.display = 'none';
        }, 300);
    }, 3000);
}

// Highlight a section to draw attention
function highlightSection(element) {
    if (!element) return;
    
    element.classList.add('highlight');
    setTimeout(() => {
        element.classList.remove('highlight');
    }, 2000);
}

// Handle form submission
async function handleFormSubmit(e) {
    e.preventDefault();
    
    // Show loading indicator
    showNotification("Envoi en cours...", "info");
    document.getElementById('submitBtn').disabled = true;
    document.getElementById('submitBtn').innerHTML = 'Traitement <i class="fas fa-spinner fa-spin"></i>';
    
    const form = e.target;
    const formData = new FormData(form);
    
    // Handle conditional fields
    const timing = form.querySelector('input[name="timing"]:checked');
    if (timing && (timing.value === "Plus de 2 mois" || timing.value === "Dans l'année")) {
        formData.delete('appointmentDate');
        formData.delete('appointmentTime');
    }
    
    // Submit the form
    try {
        const response = await fetch('http://localhost:5000/upload', {
            method: 'POST',
            body: formData,
        });
        
        if (response.ok) {
            const result = await response.json();
            if (result.status === 'success') {
                showNotification("Votre demande a été soumise avec succès !", "success");
                
                // Show success page
                steps.forEach(step => step.classList.remove('active'));
                
                // Create success step if it doesn't exist
                let successStep = document.querySelector('.success-step');
                if (!successStep) {
                    successStep = document.createElement('div');
                    successStep.className = 'step success-step active';
                    successStep.innerHTML = `
                        <div class="success-message">
                            <div class="success-icon">
                                <i class="fas fa-check-circle"></i>
                            </div>
                            <h2>Merci pour votre demande !</h2>
                            <p>Nous avons bien reçu votre demande de consultation. Un membre de notre équipe vous contactera très prochainement pour confirmer votre rendez-vous.</p>
                            <a href="/" class="button">Retour à l'accueil</a>
                        </div>
                    `;
                    form.appendChild(successStep);
                } else {
                    successStep.classList.add('active');
                }
                
                // Hide navigation buttons
                document.querySelector('.buttons').style.display = 'none';
                
            } else {
                showNotification("Erreur lors de la soumission. Veuillez réessayer.", "error");
            }
        } else {
            // Fallback for development
            showNotification("Votre demande a été soumise avec succès !", "success");
        }
    } catch (error) {
        // For development, show success anyway
        showNotification("Votre demande a été soumise avec succès !", "success");
    } finally {
        // Re-enable submit button
        document.getElementById('submitBtn').disabled = false;
        document.getElementById('submitBtn').innerHTML = 'Envoyer ma demande';
    }
}